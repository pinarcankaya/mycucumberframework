package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.FhcRegisterPage;
import pages.FhcTripLoginPage;
import utilities.ConfigurationReader;
import utilities.Driver;

public class FhcRegisterStepDef {
    FhcRegisterPage fhcRegisterPage=new FhcRegisterPage();
   // FhcTripLoginPage fhcTripLoginPage=new FhcTripLoginPage();

    @Given("kullanici fc trip sayfasindadir")
    public void kullanici_fc_trip_sayfasindadir() {
        Driver.getDriver().get(ConfigurationReader.getProperty("fhc_login_url"));
    }

    @Given("kullanici create a new account butonuna tiklar")
    public void kullanici_butonuna_tiklar(String string) {
    fhcTripLoginPage.createButton.click();
    }

    @Given("kullanici username girer")
    public void kullanici_username_girer() {
        fhcRegisterPage.username.sendKeys(ConfigurationReader.getProperty("gecerli_username"));
    }

    @Given("kullanici password girer")
    public void kullanici_password_girer() {
    
    }

    @Given("kullanici email girer")
    public void kullanici_email_girer() {

    }

    @Given("kullanici fullname girer")
    public void kullanici_fullname_girer() {

    }

    @Given("kullanici phone girer")
    public void kullanici_phone_girer() {

    }

    @Given("kullanici SSN girer")
    public void kullanici_SSN_girer() {

    }

    @Given("kullanici Driven lisans girer")
    public void kullanici_Driven_lisans_girer() {

    }

    @Given("kullanici country dropdown secer")
    public void kullanici_country_dropdown_secer() {

    }

    @Given("kullanici state dropdown secer")
    public void kullanici_state_dropdown_secer() {

    }

    @Given("kullanici adress girer")
    public void kullanici_adress_girer() {

    }

    @Given("kullanici working sector girer")
    public void kullanici_working_sector_girer() {

    }

    @Given("kullanici birthday girer")
    public void kullanici_birthday_girer() {

    }

    @Then("save butonuna tiklar")
    public void save_butonuna_tiklar() {

    }





}
